/** @file CJT_jugadores.hh
    @brief Especificación de la clase CJT_jugadores
*/

#ifndef _CJT_JUGADORES_HH_
#define _CJT_JUGADORES_HH_

#include "Jugador.hh"
#ifndef NO_DIAGRAM 
#include <iostream>
#include <map>
using namespace std;

#endif


/** @class CJT_jugadores
    @brief Representa un conjunto de jugadores. 

*/
class CJT_jugadores
{

private: 
    map<string,Jugador> jugadores;

    /** @brief Se imprimen por pantalla los jugadores del circuito. 

        Se listan los jugadores del circuito.
        \pre <em>cierto</em>
        \post El resultado es la escritura por pantalla de varios jugadores listados por orden creciente de identificador (nombre), la posición en el ranking, los puntos y el resto de las estadísticas de cada jugador del circuito.   
    */  
    void estadisticas_jugadores() const;

    /** @brief Se imprime por pantalla el jugador asociado al identificador (nombre). 
        
        Se lista un solo jugador.
        \pre <em>Cierto</em>
        \post El resultado es la escritura por pantalla de las estadísticas del jugador cuyo nombre se ha pasado por parámetro.
    */  
    void estadisticas_jugador(const string& nombre) const;
    
public:

    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automáticamente al declarar un conjunto de jugadores.
        \pre <em>Cierto.</em>
        \post El resultado es un conjunto de jugadores.
    */  
    CJT_jugadores();

    //MODIFICADORAS

    /** @brief Modificadora del conjunto de jugadores. 

        Añade un nuevo jugador (nombre) al conjunto de jugadores.
        \pre <em>Cierto.</em>
        \post El resultado es el conjunto de jugadores original más el que añadimos.   
    */  
    void anadir_nuevo_jugador(const string& nombre);

    /** @brief Modificadora del conjunto de jugadores. 

        Elimina un jugador, de identificador nombre, del conjunto de jugadores.
        \pre <em>Cierto.</em>
        \post El resultado es el conjunto de jugadores original menos el que eliminamos.   
    */  
    void eliminar_jugador(const string& nombre);

    /** @brief Modificadora de la posicion de un jugador. 

        Modifica la posicion de un jugador del conjunto, con identificador nombre, restando a este un puesto.
        \pre <em>Cierto.</em>
        \post El resultado es el jugador con la nueva posicion (la que tenía menos 1).
    */  
    void actualizar_posicion_desplazado(const string& nombre);

    /** @brief Modificadora de la puntuacion de un jugador. 

        Modifica la puntuacion de un jugador del conjunto, con identificador nombre, restando a este los puntos (p) que obtuvo la edicion anterior del torneo.
        \pre <em>Cierto.</em>
        \post El resultado es el jugador con la nueva puntuacion.
    */  
    void restar_puntos_edicion_anterior(const string& nombre, int p);

    /** @brief Modificadora de la puntuacion de un jugador. 

        Modifica la puntuacion de un jugador (nombre), sumando a este los puntos que ha obtenido el parametro implicito en la edicion actual del torneo.
        \pre <em>Cierto.</em>
        \post El resultado es el jugador con la nueva puntuacion.
    */  
    void sumar_puntos_edicion_actual(const string& nombre, int puntos_torneo);

    /** @brief Modificadora de los torneos jugados por un jugador. 

        \pre <em>Cierto.</em>
        \post El resultado es el jugador con un torneo jugado más.
    */ 
    void sumar_torneos_jugador(const string& nombre);

    /** @brief Modificadora de las estadisticas del jugador a partir del resultado de un partido. 
        
        Obtiene las estadistica
        \pre <em>Cierto.</em>
        \post Se han modificado los sets, juegos y partidos (ganados y perdidos) de los dos jugadores que participan en un partido, la función también devuelve el ganador del partido disputado.
    */  
    string obtener_estadisticas_partido(string nombre_a, string nombre_b, string res); 

    /** @brief Modificadora de las estadisticas del jugador a partir del resultado de un partido. 
        
        Obtiene las estadistica
        \pre <em>Cierto.</em>
        \post Se han modificado los sets, juegos y partidos (ganados y perdidos) de los dos jugadores que participan en un partido, la función también devuelve el ganador del partido disputado.
    */  
    void actualizar_posicion(int pos, const string& nombre);


    //CONSULTORAS

    /** @brief Consultora de la existencia de un jugador. 

        \pre <em>Cierto.</em>
        \post El resultado es true si el jugador de identificador nombre existe en el conjunto, en caso contrario, es false.
    */  
    bool existe_jugador(const string& nombre) const;

    /** @brief Consultora de la posicion de un jugador. 

        \pre <em>Cierto.</em>
        \post El resultado es un entero con la posicion en la que se encuentra el jugador del conjunto con identificador nombre.
    */  
    int consultar_posicion(const string& nombre) const;

    /** @brief Consultora del tamaño del conjunto de jugadores. 

        \pre <em>Cierto.</em>
        \post El resultado es un entero que representa el tamaño del conjunto de jugadores.
    */  
    int consultar_tamano() const;

    //SALIDA

    /** @brief Se listan los jugadores del circuito. 

        \pre <em>Cierto.</em>
        \post Se ejecutan todas las funcionalidades del comando listar jugadores.
    */
    void listar_jugadores() const;

    /** @brief Se lista un solo jugador del circuito. 

        \pre <em>Cierto.</em>
        \post Se ejecutan todas las funcionalidades del comando consultar jugador.
    */
    void consultar_jugador(const string& p) const;

    /** @brief Se escribe el numero de jugadores del conjunto de jugadores. 

        Se imprime el numero de jugadores que hay en el conjunto de jugadores.
        \pre <em>P >= 0</em>
        \post El resultado es la escritura por pantalla del entero que representa el numero de jugadores que existen en el circuito.
    */  
    void escribir_numero_jugadores() const;

    void mejor_jugador_sets(double max, int pos) const;


};
#endif
