/** @file Torneo.cc
    @brief Implementación de la clase Torneo
*/
#include "Torneo.hh"

//PRIVADAS

void Torneo::i_crear_emparejamientos(int n, int izq, int altura_max, int altura_nivel, BinTree<int> &aux) {
    int der = pow(2, altura_nivel - 1);
    if (altura_nivel >= 3) {
        if (izq%2 != 0) der = pow(2, altura_nivel - 1) - izq;
        else der = pow(2, altura_nivel - 1) - izq + 2;
    } 
    int num_jug = inscritos_edicion_act.size();
    if (der > num_jug or altura_nivel > altura_max) aux = BinTree<int>(izq);
    else {
        BinTree<int> jug1, jug2;
        i_crear_emparejamientos(n, izq, altura_max, altura_nivel + 1, jug1);
        i_crear_emparejamientos(n, der, altura_max, altura_nivel + 1, jug2);
        aux = BinTree<int> (izq, jug1, jug2);
    }
}

void Torneo::i_imprimir_cuadro_emparejamientos(const BinTree<int>& a) const {
    if (a.left().empty() and a.right().empty()) {
        cout << a.value() << "." << inscritos_edicion_act[a.value()-1].first;
    }
    else {
        cout << '(';
        i_imprimir_cuadro_emparejamientos(a.left());
        cout << ' ';
        i_imprimir_cuadro_emparejamientos(a.right());
        cout << ')';
    }
}

void Torneo::i_leer_resultados(BinTree<string>& aux) {
    string res;
    cin >> res;
    if (res != "0") {
        BinTree<string> izq, der;
        i_leer_resultados(izq);
        i_leer_resultados(der);
        aux = BinTree<string>(res, izq, der);
    }
}

void Torneo::i_calcular_resultados(CJT_jugadores& jugadores, BinTree<int>& emp, const BinTree<string>& res) {
    if (not res.empty()) {
        BinTree<int> izq = emp.left();
        BinTree<int> der = emp.right();
        
        i_calcular_resultados(jugadores,izq,res.left());
        i_calcular_resultados(jugadores,der,res.right());
        int num_a = izq.value();
        int num_b = der.value();
        string nombre_a = inscritos_edicion_act[num_a-1].first;
        string nombre_b = inscritos_edicion_act[num_b-1].first;
        string g = jugadores.obtener_estadisticas_partido(nombre_a,nombre_b,res.value());
        if (g == nombre_a) {
            emp = BinTree<int>(num_a,izq,der);
            --inscritos_edicion_act[num_a-1].second;
        }
        else {
            emp = BinTree<int>(num_b,izq,der);
            --inscritos_edicion_act[num_b-1].second;
        }
    }
}

void Torneo::i_imprimir_resultados(const BinTree<int> &emp, const BinTree<string>& res) {
    if(not emp.left().empty() or not emp.right().empty()) {
        int num_a = emp.left().value();
        int num_b = emp.right().value();
        cout << "(" << num_a << '.' << inscritos_edicion_act[num_a-1].first << " vs " << num_b << "." << inscritos_edicion_act[num_b-1].first << " " << res.value();
        i_imprimir_resultados(emp.left(), res.left());
        i_imprimir_resultados(emp.right(), res.right());
        cout << ")";
    }
}

void Torneo::obtener_estadisticas(string nombre_a, string nombre_b, string res, CJT_jugadores& jugadores) {
    jugadores.obtener_estadisticas_partido(nombre_a, nombre_b, res);
}

//CONSTRUCTORAS

Torneo::Torneo() {
}

Torneo::Torneo(int categoria) {
    this->categoria = categoria;
}

//MODIFICADORAS

void Torneo::crear_emparejamientos() {
    int n = inscritos_edicion_act.size();
    i_crear_emparejamientos(n,1,nivel_maximo,2, emparejamientos);
}



void Torneo::calcular_resultados(CJT_jugadores& jugadores) {
    i_calcular_resultados(jugadores,emparejamientos,resultados);
    finalizado = true;
}

void Torneo::sumar_torneo_jugado(CJT_jugadores& jugadores) {
    for(int i = 0; i < inscritos_edicion_act.size(); ++i){
        jugadores.sumar_torneos_jugador(inscritos_edicion_act[i].first);
    }
}

void Torneo::encontrar_jugador(const string& nombre) {
    for (int i = 0; i < inscritos_edicion_ant.size(); ++i) {
        if (inscritos_edicion_ant[i].first == nombre) {
            inscritos_edicion_ant[i].second = 0;
        }
    }
}

void Torneo::restar_puntos_edicion_anterior(bool act, CJT_jugadores& jugadores, Ranking& r) {
    for (int i = 0; i < inscritos_edicion_ant.size(); ++i) {
        int pos = jugadores.consultar_posicion(inscritos_edicion_ant[i].first);
        if (pos != -1) r.restar_puntos_edicion_anterior(pos, inscritos_edicion_ant[i].second, jugadores);
    }
    if (act and inscritos_edicion_ant.size() > 0) r.actualiza_ranking(jugadores);
}

//CONSULTORAS

int Torneo::consultar_categoria() const {
    return categoria;
}

//ENTRADA

void Torneo::leer_inscripcion_torneo(int n,Ranking& r) {
    int pos_ranking;
    nivel_maximo = ceil(log2(n)) + 1;
    inscritos_edicion_act = vector<pair<string,int> > (n);
    int num_mejores = pow(2,nivel_maximo-1)-n;
    for (int i = 0; i < n; ++i) {
    
        cin >> pos_ranking;
        inscritos_edicion_act[i].first = r.nombre_jugador(pos_ranking);
        if (i >= num_mejores) inscritos_edicion_act[i].second = nivel_maximo;
        else inscritos_edicion_act[i].second = nivel_maximo-1;
    }
    iniciado = true;
    
}

void Torneo::leer_resultados() {
    i_leer_resultados(resultados);
}

//SALIDA

void Torneo::imprimir_cuadro_emparejamientos() const {
    i_imprimir_cuadro_emparejamientos(emparejamientos);
    cout << endl;
}

void Torneo::imprimir_resultados(CJT_jugadores& jugadores, CJT_categorias& categorias, Ranking& r) {
    for (int i = 0; i < inscritos_edicion_act.size(); ++i) {
        int puntos_torneo = categorias.obtener_puntos(inscritos_edicion_act[i].second,categoria);
        inscritos_edicion_act[i].second = puntos_torneo;
        int pos = jugadores.consultar_posicion(inscritos_edicion_act[i].first);
        r.sumar_puntos_edicion_actual(pos, puntos_torneo, jugadores);
        if (puntos_torneo > 0) cout << i+1 << "." << inscritos_edicion_act[i].first << " " << puntos_torneo << endl;
    }
    inscritos_edicion_ant = inscritos_edicion_act;
}

bool Torneo::consultar_finalizado_torneo() const {
    return finalizado;
}

bool Torneo::consultar_iniciado_torneo() const {
    return iniciado;
}
void Torneo::ranking_torneo(CJT_jugadores& jugadores, Ranking& r, CJT_categorias& categorias){
    for (int i = 0; i < inscritos_edicion_act.size(); ++i) {
        int puntos_torneo = categorias.obtener_puntos(inscritos_edicion_act[i].second,categoria);
        inscritos_edicion_act[i].second = puntos_torneo;
        int pos = jugadores.consultar_posicion(inscritos_edicion_act[i].first);
        r.sumar_puntos_edicion_actual(pos, puntos_torneo, jugadores);
        if (puntos_torneo > 0) cout << i+1 << "." << inscritos_edicion_act[i].first << " " << puntos_torneo << endl;
    }
    //inscritos_edicion_ant = inscritos_edicion_act;
}

void Torneo::cambiar_inscritos() {
        inscritos_edicion_ant = inscritos_edicion_act;
}


void Torneo::res_torneo() {
    i_imprimir_resultados(emparejamientos,resultados);
    cout << endl;
}