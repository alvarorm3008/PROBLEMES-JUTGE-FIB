/** @file CJT_torneos.hh
    @brief Especificación de la clase CJT_torneos
*/

#ifndef _CJT_torneos_hh_
#define _CJT_torneos_hh_

#include "Torneo.hh"
#include "Ranking.hh"
#include "CJT_jugadores.hh"
#include "CJT_categorias.hh"

#ifndef NO_DIAGRAM 
#include <iostream>
#include <map>
#include <string>
#include "BinTree.hh"

#endif

/** @class CJT_torneos
    @brief Representa un conjunto de torneos. 

*/
class CJT_torneos 
{

private:
    map<string,Torneo> torneos;

    /** @brief Modificadora de los torneos originales del circuito. 

        Se añade un torneo al circuito.
        \pre <em>Cierto.</em>
        \post El conjunto de torneos pasa a tener los torneos originales más el añadido.
    */
    void anadir_nuevo_torneo(const string& nombre, int categoria);

        /** @brief Modificadora de los torneos originales del circuito.

        Se limina un torneo del circuito.
        \pre <em>Cierto.</em>
        \post El conjunto de torneos pasa a tener los torneos originales menos el eliminado con identificador nombre.
    */
    void eliminar_torneo(const string& nombre);

    /** @brief Modificadora del los puntos de los jugadores. 

        Se restan los puntos que consiguieron en la edicion pasada del torneo los jugadores que repiten participacion en el mismo torneo.
        \pre <em>Cierto.</em>
        \post Se ha ejecutado la acción del torneo de identificador nombre que resta los puntos de la edicion anterior de este.
    */
    void restar_puntos_edicion_anterior(const string& nombre, bool act, CJT_jugadores& jugadores, Ranking& r);

    /** @brief Lectura de la inscripcion en un torneo. 

        Se lee la inscripcion de un torneo.
        \pre <em>Cierto.</em>
        \post El resultado es la lectura de la inscripcion del torneo añadiendo al vector de inscritos actuales los nombres de los jugadores que participaran.
    */ 
    void leer_inscripcion_torneo(const string& nombre, int n, Ranking& r);

    /** @brief Accion donde se crean los emparejamientos. 

        Se crean los emparejamientos de un torneo de identificador nombre.
        \pre <em>Cierto.</em>
        \post Se ha ejecutado la acción del torneo de identificador nombre que crea los emparejamientos.
    */ 
    void crear_emparejamientos(const string& nombre);

    /** @brief Se calculan los resultados de un torneo. 

        \pre <em>Cierto.</em>
        \post Se ha ejecutado la acción del torneo de identificador nombre que calcula los resultados del torneo.
    */ 
    void calcular_resultados(const string& nombre, CJT_jugadores& jugadores);

    /** @brief Se suman los torneos jugados de un jugador. 

        \pre <em>Cierto.</em>
        \post Se ha ejecutado la acción del jugador de identificador t que suma los torneos jugados del jugador.
    */ 
    void sumar_torneos_jugados(const string& t, CJT_jugadores& jugadores);

    /** @brief Se busca a un jugador por todos los torneos. 
    
        Se busca un jugador entre los incritos de todos los torneos.
        \pre <em>Cierto.</em>
        \post Se han recorrido todos los torneos y se ha ejecutado la accion que encuentra a un jugador y pone los puntos a 0 de cada torneo recorrido.
    */
    void busqueda_jug_torneos(const string& nombre);

    /** @brief Consultora de la existencia de un torneo. 
    
        Consulta la existencia de un torneo.
        \pre <em>Cierto.</em>
        \post Devuelve true si el torneo ya existe en el circuito y false si no existe.
    */
    bool existe_torneo(const string& nombre) const;

    /** @brief Lectura de los resultados del torneo. 

        Se leen los resultados del torneo de identificador nombre.
        \pre <em>Cierto</em>
        \post El resultado es la lectura de los resultados del torneo de identificador nombre.
    */ 
    void leer_resultados(const string& nombre);

    /** @brief Escritura del numero de torneos del circuito. 

        Imprime el numero de torneos que existen en el circuito.
        \pre <em>T >= 0</em>
        \post Se imprime por pantalla el numero total de torneos en el circuito.
    */
    void escribir_numero_torneos() const;

        /** @brief Escritura del cuadro de emparejamientos de un torneo. 

        Impirme por pantalla el cuadro de emparejamientos.
        \pre <em>Cierto</em>
        \post El resultado es la escritura por pantalla del cuadro de emparejamientos del parametro implicito.
    */ 
    void imprimir_cuadro_emparejamientos(const string& nombre) const;

    /** @brief Escritura de los resultados de un torneo. 

        Imprime por pantalla los resultados del torneo.
        \pre <em>Cierto</em>
        \post El resultado es la escritura por pantalla de los resultados de un torneo de identificador nombre.
    */ 
    void imprimir_resultados(const string& nombre, CJT_jugadores&jugadores,CJT_categorias&categorias, Ranking& r);

public:

    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automáticamente al declarar un conjunto de torneos.
        \pre <em>Cierto.</em>
        \post El resultado es un conjunto de torneos.
    */  
    CJT_torneos();

    //MODIFICADORAS

    /** @brief Se da de baja un torneo del circuito. 

        \pre <em>Cierto.</em>
        \post El resultado es la ejeución de todas las funcionalidades del comando nuevo_torneo.
    */ 
    void nuevo_torneo(const string& t, int cat, int C);

    /** @brief Se da de baja un jugador de identificador p. 

        \pre <em>Cierto.</em>
        \post El resultado es la ejecución de todas las funcionalidades del comando baja_jugador.
    */
    void baja_jugador(const string& p, CJT_jugadores& jugadores, Ranking& r);

    /** @brief Se da de baja un torneo de identificador t. 

        \pre <em>Cierto.</em>
        \post El resultado es la ejecución de todas las funcionalidades del comando baja_torneo.
    */ 
    void baja_torneo(const string& t, CJT_jugadores& jugadores, Ranking& r);

    /** @brief Se inicia un torneo del circuito de identificador t y categoria n. 

        \pre <em>Cierto.</em>
        \post El resultado es la ejecución de todas las funcionalidades del comando iniciar_torneo.
    */ 
    void iniciar_torneo(const string& t, int n, Ranking& r);
    
    /** @brief Se finaliza el torneo de identificador t. 

        \pre <em>El torneo t ha sido iniciado anteriormente.</em>
        \post El resultado es la ejecución de todas las funcionalidades del comando baja_torneo.
    */ 
    void finalizar_torneo(const string& t, CJT_jugadores& jugadores, Ranking& r, CJT_categorias& catgeorias);

    //ENTRADA

    /** @brief Lectura de un conjunto inicial de torneos. 

        Se lee el conjunto inicial de torneos.
        \pre <em>T >= 0.</em>
        \post Se han leido una secuencia de T pares de strings t y enteros c, donde cada string representará el nombre del torneo y c la categoría a la que pertenece.
    */
    void leer_CJT_torneos_ini(int T);

    //SALIDA

    /** @brief Escritura por pantalla los torneos del circuito. 

        Lista los torneos del circuito.
        \pre <em>cierto</em>
        \post El resultado es la escritura por orden creciente de identificador (nombre), el nombre y la categoría de cada torneo del circuito. .
    */
    void listar_torneos(const CJT_categorias& categorias);

    void resultados_torneo(const string& t);

    bool consultar_finalizado(const string& t) const;

    bool consultar_iniciado(const string& t) const;

    void ranking_final(const string& t, CJT_jugadores& jugadores, Ranking& r, CJT_categorias& categorias);

    void imprimir(const string& nombre);
    void res(const string& t);

};
#endif
