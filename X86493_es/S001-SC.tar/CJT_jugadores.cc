/** @file CJT_jugadores.cc
    @brief Implementación de la clase CJT_jugadores
*/
#include "CJT_jugadores.hh"

//PRIVADAS

void CJT_jugadores::estadisticas_jugadores() const {
    map<string,Jugador>::const_iterator it = jugadores.begin();
    while (it != jugadores.end()) {
        cout << (*it).first << " ";
        (*it).second.escribir_estadisticas();
        cout << endl;
        ++it;
    }
}

void CJT_jugadores::estadisticas_jugador(const string& nombre) const {
    map<string,Jugador>::const_iterator it = jugadores.find(nombre);
    cout << nombre << " ";
    (*it).second.escribir_estadisticas();
    cout << endl;
}

//CONSTRUCTORAS

CJT_jugadores::CJT_jugadores() {

}

//MODIFICADORAS

void CJT_jugadores::anadir_nuevo_jugador(const string& nombre) {
    Jugador j;
    j.actualizar_posicion_anadido(jugadores.size() + 1);
    jugadores.insert(make_pair(nombre,j)); 
}

void CJT_jugadores::eliminar_jugador(const string& nombre) {
    map<string,Jugador>::iterator it = jugadores.find(nombre);
    jugadores.erase(it);
}

void CJT_jugadores::actualizar_posicion_desplazado(const string& nombre) {
    map<string,Jugador>::iterator it = jugadores.find(nombre);
    (*it).second.actualizar_posicion_desplazado();
    
}

void CJT_jugadores::restar_puntos_edicion_anterior(const string& nombre, int puntos_torneo) { 
    map<string,Jugador>:: iterator it = jugadores.find(nombre);
    (*it).second.restar_puntos(puntos_torneo);
}

void CJT_jugadores::sumar_puntos_edicion_actual(const string& nombre, int puntos_torneo) {
    map<string,Jugador>:: iterator it = jugadores.find(nombre);
    (*it).second.sumar_puntos(puntos_torneo);
}

void CJT_jugadores::sumar_torneos_jugador(const string& nombre) {
    map<string,Jugador>::iterator it = jugadores.find(nombre);
    (*it).second.sumar_torneos();
}

string CJT_jugadores::obtener_estadisticas_partido(string nombre_a, string nombre_b, string res) {
    int jga, jpa, sga, spa, pga, ppa;
    jga = jpa = sga = spa = pga = ppa = 0;

    int jgb, jpb, sgb, spb, pgb, ppb;
    jgb = jpb = sgb = spb = pgb = ppb = 0;

    if (res.length() == 11) {       
        jga = (res[0] - '0') + (res[4] - '0') + (res[8] - '0');
        jgb = (res[2] - '0') + (res[6] - '0') + (res[10] - '0');

        if (res[0]> res[2]) ++sga;
        else ++sgb;

        if (res[4] > res[6]) ++sga;
        else ++sgb;


        if (res[8] > res[10]) ++sga;
        else ++sgb;

    }
    else if (res.length() == 7) {
        jga = (res[0] - '0') + (res[4] - '0');
        jgb = (res[2] - '0') + (res[6] - '0');

        if (res[0]> res[2]) ++sga;
        else ++sgb;

        if (res[4] > res[6]) ++sga;
        else ++sgb;
    }   
    else {
        if (res[0] == '1' and res[2] == '0') ++sga;
        else if (res[0] == '0' and res[2] == '1') ++sgb;
    }
    jpa = jgb;
    jpb = jga;
    spa = sgb;
    spb = sga;
    string ganador;
    if (sga > sgb) {
        ++pga;
        ganador = nombre_a;
    }
    else {
        ++pgb;
        ganador = nombre_b;
    }

    ppa = pgb;
    ppb = pga;
    if(res.length() == 3) {
        sga = spa = sgb = spb = 0;
    }
    
    map<string,Jugador>::iterator it_a = jugadores.find(nombre_a);
    map<string,Jugador>::iterator it_b = jugadores.find(nombre_b);

    (*it_a).second.actualizar_estadisticas(jga,jpa,sga,spa,pga,ppa);
    (*it_b).second.actualizar_estadisticas(jgb,jpb,sgb,spb,pgb,ppb);
    return ganador;
}

void CJT_jugadores::actualizar_posicion(int pos, const string& nombre) {
    map<string,Jugador>::iterator it = jugadores.find(nombre);
    (*it).second.actualizar_posicion_anadido(pos);
}

//CONSULTORAS

bool CJT_jugadores::existe_jugador(const string& nombre) const {
    map<string,Jugador>::const_iterator it = jugadores.find(nombre);
    return (it != jugadores.end());
}

int CJT_jugadores::consultar_posicion(const string& nombre) const {
    map<string,Jugador>::const_iterator it = jugadores.find(nombre);
    if(it != jugadores.end()) return (*it).second.consultar_posicion();
    else return -1;
}

int CJT_jugadores::consultar_tamano() const {
    return jugadores.size();
}

//SALIDA

void CJT_jugadores::listar_jugadores() const {
    escribir_numero_jugadores();
    estadisticas_jugadores();
}

void CJT_jugadores::consultar_jugador(const string& p) const {
    if (existe_jugador(p)) estadisticas_jugador(p);
    else cout << "error: el jugador no existe" << endl;
}

void CJT_jugadores::escribir_numero_jugadores() const {
    cout << jugadores.size() << endl;
}

void CJT_jugadores::mejor_jugador_sets(double max, int pos) const {

    map<string,Jugador>::const_iterator it = jugadores.begin();
    while (it != jugadores.end()) {
        if ((*it).second.consultar_pjs() > max) {
        max = (*it).second.consultar_pjs();
        pos = (*it).second.consultar_posicion();
        }
        else if ((*it).second.consultar_pjs() == max) {
            if ((*it).second.consultar_posicion() < pos) pos = (*it).second.consultar_posicion();
        }
        ++it;
    }
    
}