/** @file CJT_torneos.cc
    @brief Implementación de la clase CJT_torneos
*/
#include "CJT_torneos.hh"

// PRIVADAS

void CJT_torneos::anadir_nuevo_torneo(const string& nombre, int categoria) {
    torneos.insert(make_pair(nombre,Torneo(categoria)));
}

void CJT_torneos::eliminar_torneo(const string& nombre) {
    torneos.erase(nombre);

}

void CJT_torneos::restar_puntos_edicion_anterior(const string& nombre, bool act, CJT_jugadores& jugadores, Ranking& r) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.restar_puntos_edicion_anterior(act, jugadores, r);
    
}

void CJT_torneos::leer_inscripcion_torneo(const string& nombre, int n, Ranking& r) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.leer_inscripcion_torneo(n,r);
}

void CJT_torneos::crear_emparejamientos(const string& nombre) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.crear_emparejamientos();
}

void CJT_torneos::calcular_resultados(const string& nombre, CJT_jugadores& jugadores) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.calcular_resultados(jugadores);
}

void CJT_torneos::sumar_torneos_jugados(const string& t, CJT_jugadores& jugadores) {
    map<string,Torneo>::iterator it = torneos.find(t);
    (*it).second.sumar_torneo_jugado(jugadores);
}

void CJT_torneos::busqueda_jug_torneos(const string& nombre) {
    map<string,Torneo>::iterator it = torneos.begin();
    while (it != torneos.end()) {
        (*it).second.encontrar_jugador(nombre);
        ++it;
    }
}

bool CJT_torneos::existe_torneo(const string& nombre) const {
    map<string,Torneo>::const_iterator it = torneos.find(nombre);
    return (it != torneos.end());
}

void CJT_torneos::leer_resultados(const string& nombre) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.leer_resultados();
}

void CJT_torneos::escribir_numero_torneos() const {
    cout << torneos.size() << endl;
}

void CJT_torneos::imprimir_cuadro_emparejamientos(const string& nombre) const {
    map<string,Torneo>::const_iterator it = torneos.find(nombre);
    (*it).second.imprimir_cuadro_emparejamientos();
}

void CJT_torneos::imprimir_resultados(const string& nombre,CJT_jugadores&jugadores,CJT_categorias&categorias, Ranking& r) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.imprimir_resultados(jugadores,categorias,r);
}

void CJT_torneos::res(const string& nombre) {
    map<string,Torneo>::iterator it = torneos.find(nombre);
    (*it).second.res_torneo();
}


//CONSTRUCTORAS

CJT_torneos::CJT_torneos() {

}

//MODIFICADORAS

void CJT_torneos::nuevo_torneo(const string& t, int cat, int C) {
    if (cat < 1 or cat > C) cout << "error: la categoria no existe" << endl;
            else if(existe_torneo(t)) cout << "error: ya existe un torneo con ese nombre" << endl;
            else {
                anadir_nuevo_torneo(t,cat);
                escribir_numero_torneos();
            }
}

void CJT_torneos::baja_jugador(const string& p, CJT_jugadores& jugadores, Ranking& r) {
     if (not jugadores.existe_jugador(p)) cout << "error: el jugador no existe" << endl;
            else {
                busqueda_jug_torneos(p);
                r.baja_jugador(p,jugadores);
            }
}

void CJT_torneos::baja_torneo(const string& t, CJT_jugadores& jugadores, Ranking& r) {
    if ( not existe_torneo(t)) cout << "error: el torneo no existe" << endl;
            else {
                restar_puntos_edicion_anterior(t,true,jugadores,r);
                eliminar_torneo(t);
                escribir_numero_torneos(); 
            }
}

void CJT_torneos::iniciar_torneo(const string& t, int n, Ranking& r) {
    leer_inscripcion_torneo(t,n,r);
    crear_emparejamientos(t);
    imprimir_cuadro_emparejamientos(t);
}
void CJT_torneos::finalizar_torneo(const string& t, CJT_jugadores& jugadores, Ranking& r,CJT_categorias& categorias) {
    restar_puntos_edicion_anterior(t,false,jugadores,r);
    leer_resultados(t);
    calcular_resultados(t,jugadores);
    imprimir_resultados(t,jugadores,categorias,r);
    sumar_torneos_jugados(t,jugadores);
    r.actualiza_ranking(jugadores);
}

//ENTRADA

void CJT_torneos::leer_CJT_torneos_ini(int T) {
    for (int i = 0; i < T; ++i) {
        string nombre;
        cin >> nombre;
        int categoria;
        cin >> categoria;
        torneos.insert(make_pair(nombre,Torneo(categoria)));
    }
}

// SALIDA

void CJT_torneos::listar_torneos(const CJT_categorias& categorias) {
    map<string,Torneo>::const_iterator it = torneos.begin();
    cout << torneos.size() << endl;
    while (it != torneos.end()) {
        cout << (*it).first << " " << categorias.consultar_nombre_categoria((*it).second.consultar_categoria()) << endl;
        ++it;
    }
}


void CJT_torneos::resultados_torneo(const string& t) {
    if (not existe_torneo(t)) cout << "error: el torneo no existe" << endl;
    else {
    if (not consultar_iniciado(t)) cout << "error: torneo no disputado" << endl;
    else if (consultar_iniciado(t) and not consultar_finalizado(t)) cout << "error: torneo en juego" << endl;
    else res(t);
    }

}

bool CJT_torneos::consultar_finalizado(const string& t) const{
    map<string,Torneo>::const_iterator it = torneos.find(t);
    return (*it).second.consultar_finalizado_torneo();
}

bool CJT_torneos::consultar_iniciado(const string&t) const {
    map<string,Torneo>::const_iterator it = torneos.find(t);
    return (*it).second.consultar_iniciado_torneo();
}

void CJT_torneos::ranking_final(const string& t, CJT_jugadores& jugadores, Ranking& r, CJT_categorias& categorias) {
    map<string,Torneo>::iterator it = torneos.find(t);
    (*it).second.ranking_torneo(jugadores,r,categorias);
}