/** @file Jugador.cc
    @brief Implementación de la clase Jugador
*/
#include "Jugador.hh"

//CONSTRUCTORAS

Jugador::Jugador() {
    posicion = 0;
    puntos = 0;
    partidos_ganados = 0;
    partidos_perdidos = 0; 
    sets_ganados = 0;
    sets_perdidos = 0;
    juegos_ganados = 0;
    juegos_perdidos = 0;
    torneos_jugados = 0;
    pjs = 0;
}

//MODIFICADORAS

double Jugador::consultar_pjs() const {
    return pjs;
}
void Jugador::actualizar_estadisticas(int jg, int jp, int sg, int sp, int pg, int pp) {
    partidos_ganados += pg;
    partidos_perdidos += pp; 
    sets_ganados += sg;
    sets_perdidos += sp;
    juegos_ganados += jg;
    juegos_perdidos += jp;
    int suma = sets_ganados + sets_perdidos;
    if (suma != 0) pjs = (sets_ganados/double(suma)) * 100;
}

void Jugador::actualizar_posicion_anadido(int i) {
    posicion = i;
}

void Jugador::actualizar_posicion_desplazado() {
    --posicion;
}

void Jugador::sumar_torneos() {
    ++torneos_jugados;
}

void Jugador::sumar_puntos(int puntos_torneo) {
    puntos += puntos_torneo;
}

void Jugador::restar_puntos(int puntos_torneo) {
    puntos -= puntos_torneo;
}

//CONSULTORAS

int Jugador::consultar_posicion() const {
    return posicion;
}

//SALIDA

void Jugador::escribir_estadisticas() const {
    cout << "Rk:" << posicion;
    cout << " Ps:" << puntos;
    cout << " Ts:" << torneos_jugados;
    cout << " WM:" << partidos_ganados;
    cout << " LM:" << partidos_perdidos;
    cout << " WS:" << sets_ganados;
    cout << " LS:" << sets_perdidos;
    cout << " WG:" << juegos_ganados;
    cout << " LG:" << juegos_perdidos;
}
