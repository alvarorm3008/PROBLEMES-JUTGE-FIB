/** @file Torneo.hh
    @brief Especificación de la clase Torneo
*/

#ifndef _TORNEO_HH_
#define _TORNEO_HH_

#include "CJT_jugadores.hh"
#include "CJT_categorias.hh"
#include "Ranking.hh"

#ifndef NO_DIAGRAM 
#include "BinTree.hh"
#include <iostream>
#include <cmath>

#endif


/** @class Torneo
    @brief Representa un torneo de tenis. 

*/
class Torneo
{

private: 
    int categoria;
    int nivel_maximo;
    vector<pair<string,int>> inscritos_edicion_ant;
    vector<pair<string,int>> inscritos_edicion_act; //int = nivel
    BinTree<int> emparejamientos;    
    BinTree<string> resultados;
    bool finalizado;
    bool iniciado;


    /** @brief Se crea el cuadro de emprejamientos del torneo. 

        \pre <em>Cierto.</em>
        \post El resultado es el cuadro de emparejamientos del torneo.
    */ 
    void i_crear_emparejamientos(int n, int ganador, int altura_max, int altura, BinTree<int>& aux);

    /** @brief Se imprime el cuadro de emprejamientos del torneo.

        \pre <em>Cierto.</em>
        \post El resultado es la escritura por pantalla del cuadro de emparejamientos de un torneo.
    */ 
    void i_imprimir_cuadro_emparejamientos(const BinTree<int>& a) const;

    /** @brief Se leen los resultados de un torneo. 

        \pre <em>Cierto.</em>
        \post El resultado es lectura de los resultados de un torneo.
    */
    static void i_leer_resultados(BinTree<string>&aux);

    /** @brief Se calcula todo lo referente a los resultados de un torneo.

        \pre <em>Cierto.</em>
        \post Se han obtenido las estadísticas, puntos obtenidos y nivel alcanzado de participante del torneo.
    */
    void i_calcular_resultados(CJT_jugadores& jugadores, BinTree<int>& emp, const BinTree<string>& res);

    /** @brief Se imprimen los resultados de un torneo.

        \pre <em>Cierto.</em>
        \post El resultado es la escritura por pantalla de los resultados de un torneo.
    */
    void i_imprimir_resultados(const BinTree<int>& emp, const BinTree<string>& res);

    /** @brief Se obtienen las estadisticas de dos jugadores que participan en el torneo a partir del resultado de un partido. 

        \pre <em>Cierto.</em>
        \post Se ejecuta la acción de obtener estadísticas de dos participantes del torneo.
    */ 
    void obtener_estadisticas(string nombre_a, string nombre_b, string res, CJT_jugadores& jugadores);
    
public:
    
    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automáticamente al declarar un torneo.
        \pre <em>Cierto.</em>
        \post El resultado es un torneo.
    */  
    Torneo();
    
    /** @brief Constructora de un torneo a partir de una categoria. 

        Se ejecuta automáticamente al declarar un torneo con categoria por parametro.
        \pre <em>categoria >= 1.</em>
        \post El resultado es un torneo de categoria <em>categoria.</em>
    */
    Torneo(int categoria);

    //MODIFICADORAS

    /** @brief Se confeccionan los emparejamientos de un torneo.

        \pre <em>Cierto.</em>
        \post El resultado es la ejecución de la acción que crea los emparejamientos del torneo.
    */  
    void crear_emparejamientos();

    /** @brief Se confeccionan los resultados de un torneo. 

        Se produce el cuadro oficial de resultados, se actualiza el ranking y las estadisticas de los jugadores que han participado en el torneo.
        \pre <em>Cierto.</em>
        \post Se ha producido el cuadro de resultados, el ranking ha sido actualizado, así como las estadisticas individuales de cada jugador.
    */ 
    void calcular_resultados(CJT_jugadores& jugadores);

    /** @brief Se suman los torneos jugados de los inscritos de la edición actual del torneo. 

        \pre <em>Cierto.</em>
        \post Se ha ejecutado la acción de sumar los torneos jugados de cada jugador perteneciente a los inscritos de la edicion actual del torneo.
    */ 
    void sumar_torneo_jugado(CJT_jugadores& jugadores);

    /** @brief Se encuentra un jugador y se ponen sus puntos a 0. 

        \pre <em>Cierto.</em>
        \post Se ha recorrido el vector de inscritos de la edicion anterior y si este se encuentra entre los inscritos se ponen sus puntos a 0.
    */ 
    void encontrar_jugador(const string& nombre);

    /** @brief Modificadora de la puntuacion de un jugador. 

        Modifica la puntuacion de un jugador, restando a esta los puntos que obtuvo la edicion pasada del torneo.
        \pre <em>Cierto.</em>
        \post El resultado es la resta de los puntos conseguidos por el jugador en la edicion pasada del torneo a la puntuacion del jugador de la posicion (pos) del ranking y se ha actualizado el ranking del circuito.
    */  
    void restar_puntos_edicion_anterior(bool act, CJT_jugadores& jugadores, Ranking& r);
    
    //CONSULTORAS

    /** @brief Consultora de la categoria de un torneo. 
     
        \pre <em>Cierto.</em>
        \post Devuelve un entero con la catgoria del parametro implicito.
    */
    int consultar_categoria() const;

    //ENTRADA

    /** @brief Lectura de la inscripcion en un torneo. 

        \pre <em>n >= 0.</em>
        \post El resultado es un torneo cuyos participantes son los jugadores identificados por su posición en el ranking, que se han leído.
    */ 
    void leer_inscripcion_torneo(int n, Ranking& r);

    /** @brief Se leen los resultados de un torneo. 

        \pre <em>Cierto.</em>
        \post Se han leido los resultados del torneo.
    */ 
    void leer_resultados();

    //SALIDA

    /** @brief Escritura del cuadro de emparejamientos de un torneo. 

        Se ejecuta automáticamente al llamar a la accion.
        \pre <em>Cierto.</em>
        \post El resultado es la escritura del cuadro de emparejamientos del parametro implicito.
    */ 
    void imprimir_cuadro_emparejamientos() const;
    
    /** @brief Escritura de los resultados de un torneo. 

        Imprime por pantalla los resultados del torneo.
        \pre <em>Cierto.</em>
        \post El resultado es la escritura por pantalla de los resultados del parametro implicito.
    */ 
    void imprimir_resultados(CJT_jugadores&jugadores,CJT_categorias&categorias, Ranking& r);

    bool consultar_finalizado_torneo() const;

    bool consultar_iniciado_torneo() const;

    void ranking_torneo(CJT_jugadores& jugadores, Ranking& r, CJT_categorias& categorias);

    void cambiar_inscritos();

    void res_torneo();

};
#endif