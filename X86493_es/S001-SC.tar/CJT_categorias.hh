/** @file CJT_categorias.hh
    @brief Especificación de la clase CJT_categorias
*/

#ifndef _CJT_CATEGORIAS_HH_
#define _CJT_CATEGORIAS_HH_

#ifndef NO_DIAGRAM
//#include "Torneo.hh"
#include <iostream>
#include <vector>
#include <string>
using namespace std;
#endif


/** @class CJT_categorias
    @brief Representa un conjunto de categorias de torneos de tenis. 

*/
class CJT_categorias
{

private:
    vector<vector<int>> categorias;
    vector<string> nombre_categorias;
public:
    
    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automáticamente al declarar un conjunto de categorias.
        \pre <em>Cierto.</em>
        \post El resultado es un conjunto de categorias.
    */  
    CJT_categorias();

    //CONSULTORAS

    /** @brief Se consulta el nombre de una categoria. 

        \pre <em>Cierto.</em>
        \post Devuelve el nombre de la categoria que consultamos.
    */  
    string consultar_nombre_categoria(int pos) const;

    /** @brief Se consultan los puntos de una categoria según el nivel. 

        \pre Nivel >= 1 y categoria >= 1.
        \post Devuelve el numero de puntos de la categoria en un cierto nivel.
    */  
    int obtener_puntos(int nivel, int categoria) const;

    //ENTRADA

    /** @brief Lectura de un conjunto de categorias inicial. 

        Se lee el conjunto de categorias inicial.
        \pre <em>C >= 1 y K >= 4.</em>
        \post Se han leío una secuencia de nombre asociados a las categorias entre 1 y C, y los puntos por categoría C y nivel K.
    */    
    void leer_CJT_categorias_ini(int C, int K);

    //SALIDA

    /** @brief Se listan las categorias del circuito.

        \pre <em>Cierto.</em>
        \post El resultado es la escritura por pantalla de las categorías de un circuito listadas por orden creciente de identificador, el nombre y
        la tabla de puntos por niveles (en orden creciente de nivel) de cada categoría del circuito.
    */  
    void listar_categorias() const;

};
#endif
