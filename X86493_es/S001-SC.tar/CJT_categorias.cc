/** @file CJT_categorias.cc
    @brief Implementación de la clase CJT_categorias
*/
#include "CJT_categorias.hh"

//CONSTRUCTORA

CJT_categorias::CJT_categorias() {

}

//CONSULTORAS

string CJT_categorias::consultar_nombre_categoria(int pos) const {
    return nombre_categorias[pos-1];
}

int CJT_categorias::obtener_puntos(int nivel, int categoria) const{
    return categorias[categoria-1][nivel-1];
}

//ENTRADA

void CJT_categorias::leer_CJT_categorias_ini(int C, int K) {
    nombre_categorias = vector<string>(C);
    for (int i = 0; i < C; ++i) cin >> nombre_categorias[i];
    categorias = vector<vector<int>>(C,vector<int>(K));
    for (int i = 0; i < C; ++i) {
        for (int j = 0; j < K; ++j) {
            cin >> categorias[i][j];
        }
    }
}

//SALIDA

void CJT_categorias::listar_categorias() const {
    cout << categorias.size() << " " << categorias[0].size() << endl;
    for (int i = 0; i < nombre_categorias.size(); ++i) {
        cout << nombre_categorias[i];
        for (int j = 0; j < categorias[0].size(); ++j) {
            cout << " " << categorias[i][j];
        }
        cout << endl;
    }
}