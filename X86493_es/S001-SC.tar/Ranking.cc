/** @file Ranking.cc
    @brief Implementación de la clase Ranking
*/
#include "Ranking.hh"

//PRIVADAS

bool Ranking::comp(const player& r1, const player& r2) {
    if(r1.puntos != r2.puntos) return r1.puntos > r2.puntos;
    else return r1.pos_anterior < r2.pos_anterior;
}

int Ranking::consultar_puntos(int pos) const {
    return ranking[pos-1].puntos;
}


int Ranking::consultar_pos_previa(int pos) const {
    return ranking[pos-1].pos_anterior;
}

//CONSTRUCTORAS

Ranking::Ranking() {

}   

Ranking::Ranking(int P) {
    ranking = vector<player> (P);
}

//MODIFICADORAS

void Ranking::baja_jugador(const string& nombre, CJT_jugadores& jugadores) {
    int i = jugadores.consultar_posicion(nombre);
    for (int j = i; j < ranking.size(); ++j) {
        ranking[j-1] = ranking[j];
        string desplazado = ranking[j-1].nombre;
        jugadores.actualizar_posicion_desplazado(desplazado);
        --ranking[j-1].pos_anterior;
    }
    ranking.pop_back();
    jugadores.eliminar_jugador(nombre);
    jugadores.escribir_numero_jugadores();
}

void Ranking::anadir_nuevo_jugador(const string& nombre, CJT_jugadores& jugadores) {
    player j;
    j.nombre = nombre;
    j.pos_anterior = ranking.size() + 1;
    j.puntos = 0;
    ranking.push_back(j);
    jugadores.anadir_nuevo_jugador(nombre);
    jugadores.escribir_numero_jugadores();
}

void Ranking::actualiza_ranking(CJT_jugadores& jugadores) {
    sort(ranking.begin(), ranking.end(), comp);
    for (int i = 0; i < ranking.size(); ++i) {
        ranking[i].pos_anterior = i+1;
        jugadores.actualizar_posicion(i+1, ranking[i].nombre);
    }    
}

void Ranking::restar_puntos_edicion_anterior(int pos, int puntos_torneo, CJT_jugadores& jugadores) {
    ranking[pos-1].puntos -= puntos_torneo;
    jugadores.restar_puntos_edicion_anterior(ranking[pos-1].nombre, puntos_torneo);
}

void Ranking::sumar_puntos_edicion_actual(int pos, int puntos_torneo, CJT_jugadores& jugadores) {
    ranking[pos-1].puntos += puntos_torneo;
    jugadores.sumar_puntos_edicion_actual(ranking[pos-1].nombre, puntos_torneo);
}

void Ranking::nuevo_jugador(const string& p, CJT_jugadores& jugadores) {
    if (jugadores.existe_jugador(p)) cout << "error: ya existe un jugador con ese nombre" << endl;
            else {
                anadir_nuevo_jugador(p,jugadores);
            }
}

//CONSULTORAS

string Ranking::nombre_jugador(int pos) const {
    return ranking[pos-1].nombre;
}

//ENTRADA

void Ranking::leer_ranking_ini(int P, CJT_jugadores& jugadores) {
    string nombre;
    for (int i = 0; i < P; ++i) {
        cin >> nombre;
        player j;
        j.nombre = nombre;
        j.pos_anterior = i+1;
        j.puntos = 0;
        ranking[i] = j;
        jugadores.anadir_nuevo_jugador(nombre);
    }
}

//SALIDA

void Ranking::listar_ranking() const {
    for (int i = 0; i < ranking.size(); ++i) {
        cout << i + 1 << " " << ranking[i].nombre << " " << ranking[i].puntos << endl;
    }
}


void Ranking::mejor_jugador(CJT_jugadores& jugadores) {
    double max = 0;
    int pos = 0;
    jugadores.mejor_jugador_sets(max,pos);
    cout << ranking[pos].nombre << " " << max << endl;
    
}