/** @file Jugador.hh
    @brief Especificación de la clase Jugador
*/

#ifndef _JUGADOR_HH_
#define _JUGADOR_HH_


#ifndef NO_DIAGRAM 
#include "BinTree.hh"
#include <iostream>

#endif


/** @class Jugador
    @brief Representa un jugador de tenis. 

*/
class Jugador
{

private:
    int posicion;
    int puntos;
    int partidos_ganados;
    int partidos_perdidos; 
    int sets_ganados;
    int sets_perdidos; 
    int juegos_ganados;
    int juegos_perdidos;
    int torneos_jugados;
    double pjs;
public:
    
    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automáticamente al declarar un jugador.
        \pre <em>Cierto.</em>
        \post El resultado es un jugador.
    */  
    Jugador();
    double consultar_pjs() const;

    //MODIFICADORAS
 
    /** @brief Modificadora de las estadisticas de un jugador. 

        Se actualizan las estadisticas de un jugador.
        \pre <em>Cierto.</em>
        \post Se han actualizado las estadisticas de un jugador, sumando a sus estadísticas originales las que recibe por parámetro la acción.
    */  
    void actualizar_estadisticas(int jg, int jp, int sg, int sp, int pg, int pp);

    /** @brief Modificadora de la posicion de un jugador. 

        Se actualiza la posicion de un jugador.
        \pre <em>Cierto.</em>
        \post Se ha actualizado la posicion del jugador, que pasara a estar en la posicion i.
    */  
    void actualizar_posicion_anadido(int i);

    /** @brief Modificadora de la posicion de un jugador. 

        Se actualiza la posicion de un jugador.
        \pre <em>Cierto.</em>
        \post Se ha actualizado la posicion del jugador, que pasara a estar en una posicion menos de la que tenía.
    */ 
    void actualizar_posicion_desplazado();

    /** @brief Se suman los torneos de un jugador.

        \pre <em>Cierto.</em>
        \post Se han sumado a los torneos que había jugado el jugador anteriormente, uno más.
    */  
    void sumar_torneos();

    /** @brief Se suman los puntos de un jugador obtenidos en un torneo.

        \pre <em>Cierto.</em>
        \post Se han sumado a los puntos del jugador, los obtenidos en el torneo en el que ha participado (puntos_torneo).
    */  
    void sumar_puntos(int puntos_torneo);

    /** @brief Se restan los puntos de un jugador obtenidos en un torneo.

        \pre <em>Cierto.</em>
        \post Se han restado a los puntos del jugador, los obtenidos en el torneo en el que ha participado (puntos_torneo).
    */  
    void restar_puntos(int puntos_torneo);

    //CONSULTORAS

    /** @brief Consultora de la posicion de un jugador. 

        Se consulta la posicion de un jugador.
        \pre <em>Cierto</em>
        \post El resultado es un entero con la posicion de un jugador.
    */  
    int consultar_posicion() const;

    //SALIDA

    /** @brief Escritura de las estadisticas del jugador. 

        Se imprimen por pantalla las estadisticas de un jugador.
        \pre <em>Cierto</em>
        \post El resultado es la escritura por pantalla de las estadisicas del parametro implicito.
    */  
    void escribir_estadisticas() const;

};
#endif