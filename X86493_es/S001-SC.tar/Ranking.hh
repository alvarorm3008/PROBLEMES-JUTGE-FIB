/** @file Ranking.hh
    @brief Especificación de la clase Ranking
*/

#ifndef _RANKING_HH_
#define _RANKING_HH_
#include "CJT_jugadores.hh"

#ifndef NO_DIAGRAM 
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

#endif


/** @class Ranking
    @brief Representa un ranking de jugadores de tenis. 

*/
class Ranking
{

private: 
    /** @brief Estructura que representa un jugador, con nombre, puntos y posición anterior del ranking
    */
    struct player{
        string nombre;
        int puntos;
        int pos_anterior;
    };
    vector<player> ranking;

    /** @brief Comparador entre dos jugadores. 

        \pre <em>Cierto.</em>
        \post Se ha devuelto un bool con el resultado de la comparació de dos elementos cualesquiera del vector, retornando si el primer elemento comparado va en la posición de delante del ranking del segundo.
    */
    static bool comp (const player& r1, const player& r2);
    
    /** @brief Consultora de los puntos de un jugador. 

        \pre <em>pos >= 1.</em>
        \post El resultado es un entero con el numero de puntos del jugador que se encuentra en la posicion (pos) del ranking.
    */  
    int consultar_puntos(int pos) const;

    /** @brief Consultora de la posición anterior de un jugador. 

        \pre <em>pos >= 1.</em>
        \post El resultado es un entero con la posicion_anterior el jugador que se encuentra en la posicion (pos) del ranking.
    */
    int consultar_pos_previa(int pos) const;

public:

    //CONSTRUCTORAS

    /** @brief Constructora por defecto. 

        Se ejecuta automaticamente al declarar un ranking.
        \pre <em>Cierto.</em>
        \post El resultado es la creacion de un ranking vacío.
    */
    Ranking();

    /** @brief Constructora de un ranking de tamaño P. 

        Se ejecuta automáticamente al declarar un ranking con tamaño.
        \pre <em>P >= 0.</em>
        \post El resultado es la creación de un ranking de tamaño P.
    */
    Ranking(int P);

    //MODIFICADORAS

    /** @brief Se da de baja un jugador del ranking.

        \pre <em>Cierto.</em>
        \post El resultado es el ranking original menos el jugador de identificador nombre eliminado.
    */
    void baja_jugador(const string& nombre, CJT_jugadores& jugadores);

    /** @brief Se añade un nuevo jugador al ranking. 

        \pre <em>Cierto.</em>
        \post El resultado es el ranking original más el nuevo jugador añadido de identificador nombre.
    */
    void anadir_nuevo_jugador(const string& nombre, CJT_jugadores& jugadores);

    /** @brief Se actualiza el ranking de los jugadores del circuito. 

        \pre <em>Cierto.</em>
        \post El resultado es el ranking de los jugadores del circuito actualizado.
    */
    void actualiza_ranking(CJT_jugadores& jugadores);

    /** @brief Modificadora de la puntuacion de un jugador. 

        Modifica la puntuacion de un jugador, restando a esta los puntos que obtuvo la edicion pasada del torneo.
        \pre <em>Cierto</em>
        \post El resultado es la resta de los puntos conseguidos por el jugador en la edicion pasada del torneo (puntos_torneo) a la puntuacion del jugador de la posicion (pos) del ranking.
    */  
    void restar_puntos_edicion_anterior(int pos, int puntos_torneo, CJT_jugadores& jugadores);
    
     /** @brief Modificadora de la puntuacion de un jugador. 

        Modifica la puntuacion de un jugador, sumando a esta los puntos que ha obtenido en la edicion actual del torneo.
        \pre <em>Cierto</em>
        \post El resultado es la suma de los puntos conseguidos por el jugador en la edicion actual del torneo (puntos_torneo) a la puntuacion del jugador de la posicion (pos) del ranking.
    */  
    void sumar_puntos_edicion_actual(int pos, int puntos_torneo, CJT_jugadores& jugadores);

    /** @brief Se ejecuta automaticamente al escribir el comando nuevo_jugador.

        \pre <em>Cierto</em>
        \post El resultado es ejecucion e todas las funcionalidades del comando nuevo_jugador.
    */  
    void nuevo_jugador(const string& p, CJT_jugadores& jugadores);

    //CONSULTORAS

    /** @brief Consultora del nombre de un jugador. 

        \pre <em>pos >= 1.</em>
        \post El resultado un string con el nombre del jugador situado en la posicion (pos) del ranking.
    */  
    string nombre_jugador(int pos) const;

    //ENTRADA

    /** @brief Lectura del ranking inicial. 

        Se leen un numero inicial de jugadores que conformaran, a su vez, el ranking inicial.
        \pre <em>P >= 0.</em>
        \post Se han leído una secuencia de P strings con los nombre de los jugadores(sin repeticiones), los cuales conformarán el ranking inicial, desde el puesto 1 hasta el iésimo, por orden de entrada.
    */
    void leer_ranking_ini(int P, CJT_jugadores& jugadores);

    //SALIDA

    /** @brief Se imprimen por pantalla el ranking del circuito. 

        Lista el ranking del circuito.
        \pre <em>Cierto</em>
        \post El resultado es la escritura por orden creciente de identificador (nombre), el nombre, la posición en el ranking, los puntos y el resto de las estadísticas de cada jugador del circuito.
    */
    void listar_ranking() const;

    void mejor_jugador(CJT_jugadores& jugadores);

};
#endif
