/** @file program.cc
    @brief Programa principal de la práctica
*/
#include "CJT_torneos.hh"
#include "CJT_categorias.hh"
#include "CJT_jugadores.hh"
#include "Ranking.hh"
using namespace std;

/** @mainpage En el módulo program.cc se encuentra el programa principal de la práctica.
 * Para la gestión de un circuito de tenis necesitaremos tener un módulo para representar el CJT_torneos que gestionará cada uno de los torneos del circuito, cada uno de estos torneo está gestionado por el módulo Torneo. Cada torneo tendrá asociada una categoría y los participantes llegarán a un cierto nivel del torneo, es por eso que será necesario tener un módulo CJT_categorias, encargado de gestionar los puntajes obtenidos en cada torneo según la categoría de este. También necesitaremos
 * otro módulo Ranking que se encargará de gestionar la clasificación de todos los jugadores del circuitos, los cuáles se encuentran tanto en el 
 * ranking cómo en el módulo CJT_jugadores, conformado por varios jugadores, donde cada uno de ellos es gestionado por el módulo Jugador.
*/

int main() {
    CJT_categorias categorias;
    CJT_torneos torneos;
    CJT_jugadores jugadores;
    
    int C, K;
    cin >> C >> K;
    categorias.leer_CJT_categorias_ini(C,K);
    int T;
    cin >> T;
    torneos.leer_CJT_torneos_ini(T);
    int P;
    cin >> P;
    Ranking r(P);
    r.leer_ranking_ini(P,jugadores);
    string comando;
    cin >> comando;
    while (comando != "fin") {

        if (comando == "nuevo_jugador" or comando == "nj") {
            string p;
            cin >> p;

            if (comando == "nuevo_jugador") cout << "#nuevo_jugador ";
            else cout << "#nj ";
            cout << p << endl;

            r.nuevo_jugador(p,jugadores);
        }

        else if (comando == "nuevo_torneo" or comando == "nt") {
            string t;
            int cat;
            cin >> t >> cat;

            if (comando == "nuevo_torneo") cout << "#nuevo_torneo ";
            else cout << "#nt ";
            cout << t << " " << cat << endl;
            
            torneos.nuevo_torneo(t,cat,C);
        }

        else if (comando == "baja_jugador" or comando == "bj") {
            string p;
            cin >> p;

            if (comando == "baja_jugador") cout << "#baja_jugador ";
            else cout << "#bj ";
            cout << p << endl;
            
            torneos.baja_jugador(p,jugadores,r);
        }

        else if (comando == "baja_torneo" or comando == "bt") {
            string t;
            cin >> t;

            if (comando == "baja_torneo") cout << "#baja_torneo ";
            else cout << "#bt ";
            cout << t << endl;
            
            torneos.baja_torneo(t,jugadores,r);
        }

        else if (comando == "iniciar_torneo" or comando == "it") {
            string t;
            int n;
            cin >> t >> n;

            if (comando == "iniciar_torneo") cout << "#iniciar_torneo ";
            else cout << "#it ";
            cout << t << endl;

            torneos.iniciar_torneo(t,n,r);
        }

        else if (comando == "finalizar_torneo" or comando == "ft") {
            string t;
            cin >> t;

            if (comando == "finalizar_torneo") cout << "#finalizar_torneo ";
            else cout << "#ft ";
            cout << t << endl;
            
            torneos.finalizar_torneo(t,jugadores,r,categorias);
        }

        else if (comando == "listar_ranking" or comando == "lr") {
            if (comando == "listar_ranking") cout << "#listar_ranking" << endl;
            else cout << "#lr" << endl;

            r.listar_ranking();
        }

        else if (comando == "listar_jugadores" or comando == "lj") {
            if (comando == "listar_jugadores") cout << "#listar_jugadores" << endl;
            else cout << "#lj" << endl;

            jugadores.listar_jugadores();
        }

        else if (comando == "consultar_jugador" or comando == "cj") {
            string p;
            cin >> p;

            if (comando == "consultar_jugador") cout << "#consultar_jugador ";
            else cout << "#cj ";
            cout << p << endl;

            jugadores.consultar_jugador(p);
        }

        else if (comando == "listar_torneos" or comando == "lt") {
            if (comando == "listar_torneos") cout << "#listar_torneos" << endl;
            else cout << "#lt" << endl;

            torneos.listar_torneos(categorias);
        }

        else if (comando == "listar_categorias" or comando == "lc") {
            if (comando == "listar_categorias") cout << "#listar_categorias" << endl;
            else cout << "#lc" << endl;

            categorias.listar_categorias();
        }
        
        else if (comando == "resultados_torneo" or comando == "rt") {
            string t;
            cin >> t;

            if (comando == "resultados_torneo") cout << "#resultados_torneo ";
            else cout << "#rt ";
            cout << t << endl;

            torneos.resultados_torneo(t);
        }

        cin >> comando;

    }

}